<?php
/**
 * Plugin Name: CRM Form Embed
 * Plugin URI: https://mail9ja.vercel.app
 * Description: Embed dynamic CRM forms in WordPress using form tokens. Minimal plugin that loads external SDK.
 * Version: 1.0.0
 * Author: Your Company
 * Author URI: https://mail9ja.vercel.app
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: crm-form-embed
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CRM_FORM_EMBED_VERSION', '1.0.0');
define('CRM_FORM_EMBED_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CRM_FORM_EMBED_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main Plugin Class
 */
class CRM_Form_Embed {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize plugin
        add_action('plugins_loaded', array($this, 'init'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        $defaults = array(
            'supabase_url' => 'https://mmdzvfbesnisndnvhytg.supabase.co',
            'supabase_anon_key' => '',
            'embed_js_url' => 'https://mail9ja.vercel.app/embed.js',
            'embed_css_url' => 'https://mail9ja.vercel.app/embed.css',
        );
        
        if (!get_option('crm_form_embed_settings')) {
            add_option('crm_form_embed_settings', $defaults);
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up if needed
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Register shortcode
        add_shortcode('crm_form', array($this, 'render_shortcode'));
        
        // Register Gutenberg block (optional)
        add_action('init', array($this, 'register_block'));
        
        // Admin settings
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Add settings link to plugin page
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_settings_link'));
    }
    
    /**
     * Register shortcode
     */
    public function render_shortcode($atts) {
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'form' => '',
            'token' => '', // Alias for 'form'
            'id' => 'crm-form-' . uniqid(), // Unique ID for multiple forms
        ), $atts, 'crm_form');
        
        // Get form token (support both 'form' and 'token' attributes)
        $form_token = !empty($atts['form']) ? $atts['form'] : $atts['token'];
        
        if (empty($form_token)) {
            return '<p style="color: red;">Error: Form token is required. Use [crm_form form="YOUR_TOKEN"]</p>';
        }
        
        // Get settings
        $settings = get_option('crm_form_embed_settings', array());
        
        // Check if SDK URLs are configured
        if (empty($settings['embed_js_url'])) {
            return '<p style="color: red;">Error: Embed SDK URL not configured. Please configure in Settings → CRM Form Embed</p>';
        }
        
        // Build container HTML
        $container_id = esc_attr($atts['id']);
        $form_token_attr = esc_attr($form_token);
        
        $html = sprintf(
            '<div id="%s" class="crm-form-container" data-form-token="%s"></div>',
            $container_id,
            $form_token_attr
        );
        
        // Add inline script to configure SDK
        $supabase_url = !empty($settings['supabase_url']) ? esc_js($settings['supabase_url']) : '';
        $supabase_key = !empty($settings['supabase_anon_key']) ? esc_js($settings['supabase_anon_key']) : '';
        $debug = defined('WP_DEBUG') && WP_DEBUG ? 'true' : 'false';
        
        $html .= '<script>';
        $html .= 'if (typeof window.CRM_SUPABASE_URL === "undefined") {';
        $html .= sprintf('window.CRM_SUPABASE_URL = "%s";', $supabase_url);
        $html .= '}';
        $html .= 'if (typeof window.CRM_SUPABASE_ANON_KEY === "undefined") {';
        $html .= sprintf('window.CRM_SUPABASE_ANON_KEY = "%s";', $supabase_key);
        $html .= '}';
        $html .= sprintf('window.CRM_DEBUG = %s;', $debug);
        $html .= '</script>';
        
        return $html;
    }
    
    /**
     * Register Gutenberg block (optional)
     */
    public function register_block() {
        // Only register if Gutenberg is available
        if (!function_exists('register_block_type')) {
            return;
        }
        
        // Register block script
        wp_register_script(
            'crm-form-embed-block',
            CRM_FORM_EMBED_PLUGIN_URL . 'block.js',
            array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components'),
            CRM_FORM_EMBED_VERSION,
            true
        );
        
        // Register block
        register_block_type('crm-form-embed/form', array(
            'editor_script' => 'crm-form-embed-block',
            'render_callback' => array($this, 'render_shortcode'),
            'attributes' => array(
                'formToken' => array(
                    'type' => 'string',
                    'default' => '',
                ),
            ),
        ));
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        $settings = get_option('crm_form_embed_settings', array());
        
        // Enqueue CSS
        if (!empty($settings['embed_css_url'])) {
            wp_enqueue_style(
                'crm-form-embed-css',
                esc_url($settings['embed_css_url']),
                array(),
                CRM_FORM_EMBED_VERSION
            );
        }
        
        // Enqueue JS (defer loading)
        if (!empty($settings['embed_js_url'])) {
            wp_enqueue_script(
                'crm-form-embed-js',
                esc_url($settings['embed_js_url']),
                array(),
                CRM_FORM_EMBED_VERSION,
                true
            );
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            __('CRM Form Embed Settings', 'crm-form-embed'),
            __('CRM Form Embed', 'crm-form-embed'),
            'manage_options',
            'crm-form-embed',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'crm_form_embed_settings',
            'crm_form_embed_settings',
            array($this, 'sanitize_settings')
        );
        
        // Supabase Settings Section
        add_settings_section(
            'crm_form_embed_supabase_section',
            __('Supabase Configuration', 'crm-form-embed'),
            array($this, 'render_supabase_section'),
            'crm-form-embed'
        );
        
        add_settings_field(
            'supabase_url',
            __('Supabase URL', 'crm-form-embed'),
            array($this, 'render_supabase_url_field'),
            'crm-form-embed',
            'crm_form_embed_supabase_section'
        );
        
        add_settings_field(
            'supabase_anon_key',
            __('Supabase Anon Key', 'crm-form-embed'),
            array($this, 'render_supabase_anon_key_field'),
            'crm-form-embed',
            'crm_form_embed_supabase_section'
        );
        
        // SDK Settings Section
        add_settings_section(
            'crm_form_embed_sdk_section',
            __('Embed SDK Configuration', 'crm-form-embed'),
            array($this, 'render_sdk_section'),
            'crm-form-embed'
        );
        
        add_settings_field(
            'embed_js_url',
            __('Embed JS URL', 'crm-form-embed'),
            array($this, 'render_embed_js_url_field'),
            'crm-form-embed',
            'crm_form_embed_sdk_section'
        );
        
        add_settings_field(
            'embed_css_url',
            __('Embed CSS URL', 'crm-form-embed'),
            array($this, 'render_embed_css_url_field'),
            'crm-form-embed',
            'crm_form_embed_sdk_section'
        );
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = array();
        
        if (isset($input['supabase_url'])) {
            $sanitized['supabase_url'] = esc_url_raw($input['supabase_url']);
        }
        
        if (isset($input['supabase_anon_key'])) {
            $sanitized['supabase_anon_key'] = sanitize_text_field($input['supabase_anon_key']);
        }
        
        if (isset($input['embed_js_url'])) {
            $sanitized['embed_js_url'] = esc_url_raw($input['embed_js_url']);
        }
        
        if (isset($input['embed_css_url'])) {
            $sanitized['embed_css_url'] = esc_url_raw($input['embed_css_url']);
        }
        
        return $sanitized;
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Check if settings were saved
        if (isset($_GET['settings-updated'])) {
            add_settings_error(
                'crm_form_embed_messages',
                'crm_form_embed_message',
                __('Settings saved successfully.', 'crm-form-embed'),
                'updated'
            );
        }
        
        settings_errors('crm_form_embed_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('crm_form_embed_settings');
                do_settings_sections('crm-form-embed');
                submit_button(__('Save Settings', 'crm-form-embed'));
                ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Usage', 'crm-form-embed'); ?></h2>
            <div class="card">
                <h3><?php _e('Shortcode', 'crm-form-embed'); ?></h3>
                <p><?php _e('Use the shortcode in any post, page, or widget:', 'crm-form-embed'); ?></p>
                <code>[crm_form form="form_live_98Fh3ksd"]</code>
                
                <h3 style="margin-top: 20px;"><?php _e('Gutenberg Block', 'crm-form-embed'); ?></h3>
                <p><?php _e('Search for "CRM Form" in the block inserter.', 'crm-form-embed'); ?></p>
                
                <h3 style="margin-top: 20px;"><?php _e('PHP', 'crm-form-embed'); ?></h3>
                <p><?php _e('Use in your theme templates:', 'crm-form-embed'); ?></p>
                <code>&lt;?php echo do_shortcode('[crm_form form="form_live_98Fh3ksd"]'); ?&gt;</code>
            </div>
            
            <h2 style="margin-top: 30px;"><?php _e('Getting Your Form Token', 'crm-form-embed'); ?></h2>
            <div class="card">
                <p><?php _e('Form tokens are generated in your CRM dashboard. Each form has a unique token that looks like:', 'crm-form-embed'); ?></p>
                <code>form_live_98Fh3ksd</code>
                <p style="margin-top: 10px;"><?php _e('Copy the token from your dashboard and paste it in the shortcode.', 'crm-form-embed'); ?></p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render Supabase section
     */
    public function render_supabase_section() {
        echo '<p>' . __('Configure your Supabase project credentials. These are used by the embed SDK to fetch form schemas and submit orders.', 'crm-form-embed') . '</p>';
    }
    
    /**
     * Render SDK section
     */
    public function render_sdk_section() {
        echo '<p>' . __('Configure the URLs for the embed SDK files. These should point to your hosted embed.js and embed.css files.', 'crm-form-embed') . '</p>';
    }
    
    /**
     * Render Supabase URL field
     */
    public function render_supabase_url_field() {
        $settings = get_option('crm_form_embed_settings', array());
        $value = isset($settings['supabase_url']) ? $settings['supabase_url'] : '';
        ?>
        <input type="url" 
               name="crm_form_embed_settings[supabase_url]" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="https://mmdzvfbesnisndnvhytg.supabase.co">
        <p class="description"><?php _e('Your Supabase project URL. Found in Settings → API.', 'crm-form-embed'); ?></p>
        <?php
    }
    
    /**
     * Render Supabase Anon Key field
     */
    public function render_supabase_anon_key_field() {
        $settings = get_option('crm_form_embed_settings', array());
        $value = isset($settings['supabase_anon_key']) ? $settings['supabase_anon_key'] : '';
        ?>
        <input type="text" 
               name="crm_form_embed_settings[supabase_anon_key]" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...">
        <p class="description"><?php _e('Your Supabase anon/public key. Found in Settings → API. Safe to use in client-side code.', 'crm-form-embed'); ?></p>
        <?php
    }
    
    /**
     * Render Embed JS URL field
     */
    public function render_embed_js_url_field() {
        $settings = get_option('crm_form_embed_settings', array());
        $value = isset($settings['embed_js_url']) ? $settings['embed_js_url'] : 'https://mail9ja.vercel.app/embed.js';
        ?>
        <input type="url" 
               name="crm_form_embed_settings[embed_js_url]" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="https://mail9ja.vercel.app/embed.js">
        <p class="description"><?php _e('URL to your hosted embed.js file.', 'crm-form-embed'); ?></p>
        <?php
    }
    
    /**
     * Render Embed CSS URL field
     */
    public function render_embed_css_url_field() {
        $settings = get_option('crm_form_embed_settings', array());
        $value = isset($settings['embed_css_url']) ? $settings['embed_css_url'] : 'https://mail9ja.vercel.app/embed.css';
        ?>
        <input type="url" 
               name="crm_form_embed_settings[embed_css_url]" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="https://mail9ja.vercel.app/embed.css">
        <p class="description"><?php _e('URL to your hosted embed.css file.', 'crm-form-embed'); ?></p>
        <?php
    }
    
    /**
     * Add settings link to plugin page
     */
    public function add_settings_link($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            admin_url('options-general.php?page=crm-form-embed'),
            __('Settings', 'crm-form-embed')
        );
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize plugin
CRM_Form_Embed::get_instance();
