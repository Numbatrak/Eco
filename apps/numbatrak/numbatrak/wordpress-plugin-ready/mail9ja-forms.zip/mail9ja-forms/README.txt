=== Mail9ja Forms ===
Contributors: mail9ja
Tags: forms, crm, embed, supabase, mail9ja, order-forms
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed dynamic order forms from Mail9ja CRM into your WordPress site.

== Description ==

Mail9ja Forms allows you to embed dynamic order forms from your Mail9ja CRM directly into your WordPress site. Forms are fetched from your Supabase database and rendered dynamically with full support for all field types including radio groups with product selection.

**Features:**
* Easy shortcode integration
* Support for all form field types (text, email, phone, number, textarea, select, radio-group)
* Radio groups with product selection
* Automatic cache-busting for fresh form data
* Gutenberg block support
* Minimal plugin footprint - loads external SDK

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/mail9ja-forms` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Settings → Mail9ja Forms to configure your Supabase credentials
4. Use the shortcode [mail9ja_form form="YOUR_FORM_TOKEN"] in any post or page

== Frequently Asked Questions ==

= How do I get my form token? =

Log into your Mail9ja CRM dashboard, go to Forms, and copy the form token for the form you want to embed.

= Where do I get my Supabase credentials? =

Go to your Supabase dashboard → Settings → API. Copy the Project URL and anon/public key.

= What shortcode should I use? =

Use [mail9ja_form form="YOUR_FORM_TOKEN"] or the alias [mail9ja_forms form="YOUR_FORM_TOKEN"]

== Changelog ==

= 2.0.0 =
* Complete plugin rename to Mail9ja Forms
* Support for all form field types including radio groups
* Cache-busting for fresh form data
* Improved radio button rendering
* Version logging for debugging

= 1.0.0 =
* Initial release as CRM Form Embed

== Upgrade Notice ==

= 2.0.0 =
Major update with plugin rename. If upgrading from CRM Form Embed, you'll need to:
1. Deactivate old plugin
2. Install new Mail9ja Forms plugin
3. Reconfigure settings
4. Update shortcodes from [crm_form] to [mail9ja_form]
